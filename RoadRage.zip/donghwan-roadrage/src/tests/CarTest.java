package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;
import model.Car;
import model.Direction;
import model.Light;
import model.Terrain;
import org.junit.Test;

public class CarTest {
    
    @Test
    public void testCarConstructor() {
        final Car c = new Car(10, 12, Direction.NORTH);
        
        assertEquals("Car x coordinate not initialized correctly!", 10, c.getX());
        assertEquals("Car y coordinate not initialized correctly!", 12, c.getY());
        assertEquals("Car direction not initialized correctly!", 
                     Direction.NORTH, c.getDirection());
        assertEquals("Car death time not initialized correctly!", 15, c.getDeathTime());
        assertTrue("Car isAlive() fails initially!", c.isAlive());
    }
    
    @Test
    public void testCarCanPass() {
        final Car c = new Car(10, 12, Direction.NORTH);
        
        assertFalse("Car should not be able to pass", c.canPass(Terrain.WALL, Light.GREEN));
        assertTrue("Car should be able to pass", c.canPass(Terrain.STREET, Light.RED));
        assertFalse("Car should not be able to pass", c.canPass(Terrain.TRAIL, Light.GREEN));
        
        assertTrue("Car should be able to pass", c.canPass(Terrain.LIGHT, Light.GREEN));
        assertFalse("Car should not be able to pass", c.canPass(Terrain.LIGHT, Light.RED));
        
        assertFalse("Car should not be able to pass", 
                    c.canPass(Terrain.CROSSWALK, Light.YELLOW));
        assertTrue("Car should be able to pass", c.canPass(Terrain.CROSSWALK, Light.GREEN));
        assertFalse("Car should not be able to pass", c.canPass(Terrain.CROSSWALK, Light.RED));
        
    }
    
    @Test
    public void testCarChooseDirectionOneValidDirection() {
        final Car c = new Car(10, 12, Direction.NORTH);
        
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.NORTH, Terrain.GRASS);
        neighbors.put(Direction.SOUTH, Terrain.WALL);
        neighbors.put(Direction.WEST, Terrain.WALL);
        neighbors.put(Direction.EAST, Terrain.STREET);
        
        assertEquals("Car should have picked West", 
                     Direction.EAST, c.chooseDirection(neighbors));
    }
    @Test
    public void testCarChooseDirectionReverse() {
        
        final Car c = new Car(10, 12, Direction.NORTH);
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        
        neighbors.put(Direction.NORTH, Terrain.WALL);
        neighbors.put(Direction.SOUTH, Terrain.STREET);
        neighbors.put(Direction.WEST, Terrain.TRAIL);
        neighbors.put(Direction.EAST, Terrain.GRASS);
        
        assertEquals("Car should have picked South", 
                    Direction.SOUTH, c.chooseDirection(neighbors));
    }
}