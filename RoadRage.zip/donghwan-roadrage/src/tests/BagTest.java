package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import model.Bag;
import org.junit.Test;


public class BagTest {
    
    
    
    
    //check if Bag() can construct a bag with type integers
    @Test
    public void testBagConstructorInteger() {
        final Bag<Integer> intBag = new Bag<>(1, 2, 3, 4, 5, 6, 7, 8);
        final Bag<Integer> intBag2 = new Bag<>();
        
        //bag should have 8 items in it
        assertEquals("Bag size should be 8.", 8, intBag.size());
        
        //bag should have 0 items in it
        assertEquals("Bag size should be 0.", 0, intBag2.size());
    }
    
    //check if Bag() can construct a bag with type strings
    @Test
    public void testBagConstructorString() {
        final Bag<String> intBag = new Bag<>("one", "two", "threee",
                        "four", "five", "six", "seven", "eight");
        final Bag<String> intBag2 = new Bag<>();
        
        //bag should have 8 items in it
        assertEquals("Bag size should be 8.", 8, intBag.size());
        
        //bag should have 0 items in it
        assertEquals("Bag size should be 0", 0, intBag2.size());
    }
    
    @Test
    public void testBagPut() {
        final Bag<Integer> intBag = new Bag<>(1, 2, 3, 4, 5, 6, 7, 8);
        
        //bag should have 8 items in it
        assertEquals("Bag size should be 8.", 8, intBag.size());
        
        //bag should not take elements 4 or 6
        //bag should have 14 items in it
        intBag.put(4, 6, 9, 10, 11, 12, 13, 14);
        assertEquals("Bag size should be 14.", 14, intBag.size());
    }
    
    @Test
    public void testBagClear() {
        final Bag<Integer> intBag = new Bag<>(1, 2, 3, 4, 5, 6, 7, 8);
        
        //bag should have 8 items in it
        assertEquals("Bag size should be 8.", 8, intBag.size());
        
        //bag should be cleared
        //bag should have 0 items in it
        intBag.clear();
        assertEquals("Bag size should be 0.", 0, intBag.size());
    }
    
    @Test
    public void testBagToString() {
        final Bag<Integer> intBag = new Bag<>(1, 2, 3, 4, 5, 6, 7, 8);
        
        //bag should have 8 items in it
        assertEquals("Bag size should be 8.", 8, intBag.size());
        
        //toString should return all elements in the bag
        assertEquals("Bag should output integers from 1 to 8",
                     "[1, 2, 3, 4, 5, 6, 7, 8]", intBag.toString());
    }
    
    @Test
    public void testBagPull() {
        final Bag<Integer> intBag = new Bag<>(1, 2, 3, 4, 5, 6, 7, 8);
        
        //pull items from the bag
        for (int i = 1; i <= intBag.size(); i++) {
            //items pulled is ordered and bag has ordered elements.
            //bag should pull items in order
            assertEquals("The element: " + i + ", should have been pulled.",
                         i, (int) intBag.pull());
        }
    }
    
    // 1) Construct 2 bags with identical items
    // 2) put items randomly into another 2 bags
    // 3) check if the 2 bags have the same sequence of items
        // SHOULD NOT BE THE CASE, OVER 1000 TIMES WITH MARGIN OF 8 SAME SEQUENCE OF ITEMS
    @Test
    public void testBagPullRandom() {
        
        //repeat 1000 times
        int repeat = 0;
        while (repeat < 1000) {
            final Bag<Integer> intBag1 = new Bag<>(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
            final Bag<Integer> intBag2 = new Bag<>(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
            final Bag<Integer> intBagTest1 = new Bag<>();
            final Bag<Integer> intBagTest2 = new Bag<>();
            
            //holds initial size of bag
            final int initialSize = intBag1.size();
            
            //pull items (randomly) from the bag and assign them to new bag
            for (int i = 1; i <= initialSize; i++) {
                
                //pull items randomly from bag1 & bag2,
                //put items in new bag1 & bag2
                intBagTest1.put(intBag1.pullRandom());
                intBagTest2.put(intBag2.pullRandom());
            }
            
            //only 8 
            final int randomMargin = 8;
            int sameNum = 0;
            for (int i = 1; i <= initialSize; i++) {
                if (intBagTest1.pull() == intBagTest2.pull()) {
                    sameNum++;
                }
            }
            //can't pull 8 same items from 2 bags with made from random pulls
            assertTrue("The Bag had over 7 elements in same index." ,
                       sameNum < randomMargin);
            repeat++;
        }
    }
}