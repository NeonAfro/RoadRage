package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;
import model.Atv;
import model.Direction;
import model.Light;
import model.Terrain;
import org.junit.Test;

public class AtvTest {
    
    @Test
    public void testAtvConstructor() {
        final Atv a = new Atv(10, 12, Direction.NORTH);
        
        assertEquals("Atv x coordinate not initialized correctly!", 10, a.getX());
        assertEquals("Atv y coordinate not initialized correctly!", 12, a.getY());
        assertEquals("Atv direction not initialized correctly!", 
                     Direction.NORTH, a.getDirection());
        assertEquals("Atv death time not initialized correctly!", 25, a.getDeathTime());
        assertTrue("Atv isAlive() fails initially!", a.isAlive());
    }
    
    @Test
    public void testAtvCanPass() {
        final Atv a = new Atv(10, 12, Direction.NORTH);
        
        assertFalse("Atv should not be able to pass", a.canPass(Terrain.WALL, Light.GREEN));
        assertTrue("Atv should be able to pass", a.canPass(Terrain.STREET, Light.RED));
    }
    
    @Test
    public void testAtvChooseDirectionOneValidDirection() {
        final Atv a = new Atv(10, 12, Direction.NORTH);
        
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.NORTH, Terrain.GRASS);
        neighbors.put(Direction.SOUTH, Terrain.WALL);
        neighbors.put(Direction.WEST, Terrain.WALL);
        neighbors.put(Direction.EAST, Terrain.WALL);
        
        assertEquals("Atv should have picked North", 
                     Direction.NORTH, a.chooseDirection(neighbors));
    }
    @Test
    public void testAtvChooseDirectionTwoValidDirection() {
        
        final Atv a = new Atv(10, 12, Direction.NORTH);
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        
        neighbors.put(Direction.NORTH, Terrain.CROSSWALK);
        neighbors.put(Direction.SOUTH, Terrain.STREET);
        neighbors.put(Direction.WEST, Terrain.WALL);
        neighbors.put(Direction.EAST, Terrain.GRASS);
        
        // test if method returns a valid direction 100 times
        int checkRandom = 0;
        while (checkRandom < 100) {
            assertTrue("The Direction should be valid!" , 
                       isValidTerrain(neighbors.get(a.chooseDirection(neighbors))));
            
            checkRandom++;
        }
    }
    @Test
    public void testAtvChooseReverse() {
        final Atv a = new Atv(10, 12, Direction.NORTH);
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        
        neighbors.put(Direction.NORTH, Terrain.WALL);
        neighbors.put(Direction.SOUTH, Terrain.STREET);
        neighbors.put(Direction.WEST, Terrain.WALL);
        neighbors.put(Direction.EAST, Terrain.WALL);
        
        assertEquals("Atv should have picked South", Direction.SOUTH,
                     a.chooseDirection(neighbors));
    }
    public boolean isValidTerrain(final Terrain theTerrain) {
        boolean result = true;
        if (theTerrain.equals(Terrain.WALL)) {
            result = false;
        }
        return result;
    }
    @Test
    public void testChooseDirectionSurroundedByValidTerrain() {
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.WEST, Terrain.GRASS);
        neighbors.put(Direction.NORTH, Terrain.STREET);
        neighbors.put(Direction.EAST, Terrain.TRAIL);
        neighbors.put(Direction.SOUTH, Terrain.GRASS);
        
        boolean seenWest = false;
        boolean seenNorth = false;
        boolean seenEast = false;
        boolean seenSouth = false;
        
        final Atv a = new Atv(0, 0, Direction.NORTH);
        
        for (int count = 0; count < 100; count++) {
            final Direction d = a.chooseDirection(neighbors);
            
            if (d == Direction.WEST) {
                seenWest = true;
            } else if (d == Direction.NORTH) {
                seenNorth = true;
            } else if (d == Direction.EAST) {
                seenEast = true;
            } else if (d == Direction.SOUTH) { // this should NOT be chosen
                seenSouth = true;
            }
        }
 
        assertTrue("Atv chooseDirection() fails to select randomly "
                   + "among all possible valid choices!",
                   seenWest && seenNorth && seenEast);
            
        assertFalse("Atv chooseDirection() reversed direction when not necessary!",
                    seenSouth);
    }
}