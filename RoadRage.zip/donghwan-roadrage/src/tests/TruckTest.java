package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;
import model.Direction;
import model.Light;
import model.Terrain;
import model.Truck;
import org.junit.Test;

public class TruckTest {
    
    @Test
    public void testTruckConstructor() {
        final Truck t = new Truck(10, 12, Direction.NORTH);
        
        assertEquals("Truck x coordinate not initialized correctly!", 10, t.getX());
        assertEquals("Truck y coordinate not initialized correctly!", 12, t.getY());
        assertEquals("Truck x coordinate not initialized correctly!", 
                     Direction.NORTH, t.getDirection());
        assertEquals("Truck death time not initialized correctly!", 0, t.getDeathTime());
        assertTrue("Truck isAlive() fails initially!", t.isAlive());
    }
    
    @Test
    public void testTruckCanPass() {
        final Truck t = new Truck(10, 12, Direction.NORTH);
  
        assertTrue("Truck should be able to pass", t.canPass(Terrain.STREET, Light.RED));
        assertTrue("Truck should be able to pass", 
                   t.canPass(Terrain.CROSSWALK, Light.GREEN));
        
        assertFalse("Truck should not be able to pass", 
                    t.canPass(Terrain.CROSSWALK, Light.RED));
        assertFalse("Truck should not be able to pass", t.canPass(Terrain.WALL, Light.GREEN));
        assertFalse("Truck should not be able to pass", t.canPass(Terrain.GRASS, Light.GREEN));
        assertFalse("Truck should not be able to pass", t.canPass(Terrain.TRAIL, Light.GREEN));
         
    }
    
    @Test
    public void testTruckChooseDirectionOneValidDirection() {
        final Truck t = new Truck(10, 12, Direction.NORTH);
        
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.NORTH, Terrain.GRASS);
        neighbors.put(Direction.SOUTH, Terrain.WALL);
        neighbors.put(Direction.WEST, Terrain.STREET);
        neighbors.put(Direction.EAST, Terrain.TRAIL);
        
        assertEquals("Truck should have picked West", 
                     Direction.WEST, t.chooseDirection(neighbors));
        
        // test if method returns a valid direction 100 times
        int checkRandom = 0;
        while (checkRandom < 100) {
            assertTrue("Truck chooseDirection should always give valid direction.", 
                       isValidTerrain(neighbors.get(t.chooseDirection(neighbors))));
            
            checkRandom++;
        }
    }
    @Test
    public void testCarChooseDirectionReverse() {
        
        final Truck t = new Truck(10, 12, Direction.NORTH);
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        
        neighbors.put(Direction.NORTH, Terrain.WALL);
        neighbors.put(Direction.SOUTH, Terrain.STREET);
        neighbors.put(Direction.WEST, Terrain.TRAIL);
        neighbors.put(Direction.EAST, Terrain.GRASS);
        
        assertEquals("Truck should have picked South", 
                    Direction.SOUTH, t.chooseDirection(neighbors));
    }
    @Test
    public void testCarPassCrossWalkAfterLight() {
        
        final Truck t = new Truck(10, 12, Direction.NORTH);
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        
        neighbors.put(Direction.NORTH, Terrain.WALL);
        neighbors.put(Direction.SOUTH, Terrain.CROSSWALK);
        neighbors.put(Direction.WEST, Terrain.TRAIL);
        neighbors.put(Direction.EAST, Terrain.GRASS);
        
        //truck needs to face the crosswalk, as there are no other choices
        t.setDirection(t.chooseDirection(neighbors));
        
        //truck can't pass the crosswalk at red light
        assertFalse("Truck should be able to pass Crosswalk at Red Light", 
                   t.canPass(neighbors.get(t.getDirection()), Light.RED));
        
        //truck must choose to go through the crosswalk after the light changes
        assertEquals("Truck should have picked South", 
                    Direction.SOUTH, t.chooseDirection(neighbors));
    }
    
    private boolean isValidTerrain(final Terrain theTerrain) {
       
        boolean result = true;

        if (theTerrain.equals(Terrain.WALL) 
                        || theTerrain.equals(Terrain.GRASS) 
                        || theTerrain.equals(Terrain.TRAIL)) {
            result = false;
        }
        return result;
    }
    @Test
    public void testChooseDirectionSurroundedByStreet() {
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.WEST, Terrain.STREET);
        neighbors.put(Direction.NORTH, Terrain.STREET);
        neighbors.put(Direction.EAST, Terrain.STREET);
        neighbors.put(Direction.SOUTH, Terrain.GRASS);
        
        boolean seenWest = false;
        boolean seenNorth = false;
        boolean seenEast = false;
        boolean seenSouth = false;
        
        final Truck t = new Truck(0, 0, Direction.NORTH);
        
        for (int count = 0; count < 100; count++) {
            final Direction d = t.chooseDirection(neighbors);
            
            if (d == Direction.WEST) {
                seenWest = true;
            } else if (d == Direction.NORTH) {
                seenNorth = true;
            } else if (d == Direction.EAST) {
                seenEast = true;
            } else if (d == Direction.SOUTH) { // this should NOT be chosen
                seenSouth = true;
            }
        }
 
        assertTrue("Truck chooseDirection() fails to select randomly "
                   + "among all possible valid choices!",
                   seenWest && seenNorth && seenEast);
            
        assertFalse("Truck chooseDirection() reversed direction when not necessary!",
                    seenSouth);
    }
}