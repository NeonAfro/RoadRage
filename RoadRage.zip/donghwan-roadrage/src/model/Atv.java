/**
 * TCSS 305 - Road Rage
 */
package model;

import java.util.Map;


/**
 * A Vehicle Type for The Road Rage application. 
 * 
 * @author Donghwan (Luke) Chung
 * @version Winter 2023
 */
public class Atv extends AbstractVehicle implements Vehicle {
    
    /** Death time of Atv. */
    private static final int ATV_DEATH_TIME = 25;
    
    /**
     * Constructor for Atv. Keeps all variables in parent class.
     * 
     * @param theX sets theX coordinate for Atv
     * @param theY sets theY coordinate for Atv
     * @param theDir sets the direction the Atv is facing
     */
    public Atv(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, ATV_DEATH_TIME);
    }
    
    /** Checks if Atv can pass the given terrain with the given
     *  light sign.
     *  Atv can pass any terrain but the wall
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
       
        if (theTerrain == Terrain.WALL) {
            return false;
        }
        return true;
    }

    /** Gives the next direction the Atv should go.
     *  Atv randomly chooses to go straight, left, or right.
     *  Atv never turns backwards, as it never has to.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {

        return giveRandomDirection(theNeighbors, super.getDirection(), 
                                   super.getDirection().right(), 
                                   super.getDirection().left());
    }

    /**
     * Checks if the Terrain is valid for Atv to pass.
     * Helper method for canPass & giveRandomDirection method.
     * 
     * @param theTerrain checked if Atv can pass it
     * @return true if the Terrain is not a wall
     */
    private boolean isValidTerrain(final Terrain theTerrain) {
        
        if (theTerrain.equals(Terrain.WALL)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Checks which random direction (straight, left, or right) Atv wants
     * to move.
     * Helper method for chooseDirection method.
     * 
     * @param theNeighbors map that shows what terrains are around Atv
     * @param theDirections possible directions of Atv
     * @return a random direction (straight, left, or right)
     */
    private Direction giveRandomDirection(final Map<Direction, Terrain> theNeighbors,
                                      final Direction... theDirections) {
        
        //create a bag data structure
        final Bag<Direction> bag = new Bag<>();
        
        //put all direction in bag
        for (Direction d : theDirections) {
            bag.put(d);
        }
        
        //pull random direction from bag
        Direction randomDir = bag.pullRandom();
        
        //while random direction in not valid,
        //keeping pulling random direction from bag
        while (!isValidTerrain(theNeighbors.get(randomDir))) {
            
            //reverses if bag size is 0 (not necessary for Atv)
            if (bag.size() == 0) {
                return getDirection().reverse();
            }
            randomDir = bag.pullRandom();
        }
        //return random direction that is valid
        return randomDir;
    }
}