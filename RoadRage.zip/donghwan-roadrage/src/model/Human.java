/**
 * TCSS 305 - Road Rage
 */

package model;

import java.util.Map;


/**
 * A Vehicle Type for The Road Rage application. 
 * 
 * @author Donghwan (Luke) Chung
 * @version Winter 2023
 */
public class Human extends AbstractVehicle {

    /** Death time of Human. */
    private static final int HUMAN_DEATH_TIME = 45;
    
    /**
     * Constructor for Human. Keeps all variables in parent class.
     * 
     * @param theX sets theX coordinate for Human
     * @param theY sets theY coordinate for Human
     * @param theDir sets the direction the Human is facing
     */
    public Human(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, HUMAN_DEATH_TIME);
    }
    
    /** Checks if Human can pass the given terrain with the given
     *  light sign.
     *  Human can only traverse on grass, and crosswalk (when light is not green).
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        
        //only allowed to return 3 times
        boolean result = false;
        
        if (isValidTerrain(theTerrain)) {
            
            if (theTerrain.equals(Terrain.CROSSWALK) 
                          && isNotValidCrossWalkLight(theLight)) {
                result = false;
                return result;
            }
            
            result = true;
        }
        
        return result;
    }

    /** Gives the next direction the Human should go.
     *  Human randomly chooses to go straight, left, or right.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        
        // Direction[] represents possible directions by preferrence (Human):
        //       [myDir, myDir.left(), myDir.right()]
        return preferredDirection(theNeighbors, 
                                  new Direction[] {super.getDirection(),
                                                  super.getDirection().left(), 
                                                  super.getDirection().right()});
    }
    
    /**
     * Checks which light state, for crosswalk, the Human should stop for.
     * Helper method for canPass method.
     * 
     * @param theLight the light state
     * @return true if light state is GREEN
     */
    private boolean isNotValidCrossWalkLight(final Light theLight) {
        
        if (theLight.equals(Light.GREEN)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Checks if the Terrain is valid for Human to pass.
     * Helper method for canPass, preferredDirection, & giveRandomDirection method.
     * 
     * @param theTerrain the terrain being checked
     * @return true if Terrain is a crosswalk or grass
     */
    private boolean isValidTerrain(final Terrain theTerrain) {
        
        // only traverses grass and crosswalks
        if (theTerrain.equals(Terrain.CROSSWALK) 
                        || theTerrain.equals(Terrain.GRASS)) {
            return true;
        }
        return false;
    }
    /**
     * Checks if there is a cross walk straight, left, or right of Human,
     * then goes through all possible directions by random:
     * straight, left, right. Reverses direction if all directions are exhausted.
     * Helper method for chooseDirection method.
     * 
     * @param theNeighbors map that shows what terrains are around Human
     * @param theDirections possible directions of Human
     * @return direction facing crosswalk, or random direction if no crosswalk
     */
    private Direction preferredDirection(final Map<Direction, Terrain> theNeighbors,
                                        final Direction[] theDirections) {
        
        //create a bag data structure
        final Bag<Direction> bag = new Bag<>();
        
        //put all direction in bag
        for (Direction d : theDirections) {
            bag.put(d);
        }
       
        //pull direction from bag
        Direction chosenDir = bag.pull();
        
        //while the direction is not crosswalk,
        //keep pulling direction from bag
        while (!(theNeighbors.get(chosenDir).equals(Terrain.CROSSWALK))) {
            
            //gets random direction (right, left, straight) 
            //if no crosswalks are near
            if (bag.size() == 0) {
                return giveRandomDirection(theNeighbors, theDirections);
            }
            chosenDir = bag.pull();
        }
        //return the direction with crosswalk on it
        return chosenDir;
    }
    
    /**
     * Checks which random direction (straight, left, or right) Human wants
     * to move. Reverses direction if no directions are available.
     * Helper method for chooseDirection & preferredDirection method.
     * 
     * @param theNeighbors map that shows what terrains are around Human
     * @param theDirections possible directions of Human
     * @return a random direction (straight, left, or right), reverse if 
     *         all possible directions are invalid
     */
    private Direction giveRandomDirection(final Map<Direction, Terrain> theNeighbors,
                                          final Direction... theDirections) {
            
        
        //create a bag data structure
        final Bag<Direction> bag = new Bag<>();
        
        //put all direction in bag
        for (Direction d : theDirections) {
            bag.put(d);
        }
        
        //pull random direction from bag
        Direction randomDir = bag.pullRandom();
        
        //while random direction is not valid,
        //keep pulling random direction from bag
        while (!isValidTerrain(theNeighbors.get(randomDir))) {
            
            //reverses if no more directions are in bag
            if (bag.size() == 0) {
                return getDirection().reverse();
            }
            randomDir = bag.pullRandom();
        }
        //return random direction that is valid
        return randomDir;
    }
}