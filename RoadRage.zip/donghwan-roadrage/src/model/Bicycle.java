/**
 * TCSS 305 - Road Rage
 */

package model;

import java.util.Map;


/**
 * A Vehicle Type for The Road Rage application. 
 * 
 * @author Donghwan (Luke) Chung
 * @version Winter 2023
 */
public class Bicycle extends AbstractVehicle {

    /** Death time of Bicycle. */
    private static final int BICYCLE_DEATH_TIME = 35;
    
    /**
     * Constructor for Bicycle. Keeps all variables in parent class.
     * 
     * @param theX sets theX coordinate for Bicycle
     * @param theY sets theY coordinate for Bicycle
     * @param theDir sets the direction the Bicycle is facing
     */
    public Bicycle(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, BICYCLE_DEATH_TIME);
    }
    
    /** Checks if Bicycle can pass the given terrain with the given
     *  light sign.
     *  Bicycle can only traverse on streets and trails, and through crosswalks.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        
        boolean result = true;
        if (isNotValidLight(theLight) && theTerrain.equals(Terrain.CROSSWALK) 
                        || isNotValidLight(theLight) && theTerrain.equals(Terrain.LIGHT)) {
            result = false;
        }
        
        return result;
    }

    /** Gives the next direction the Bicycle should go.
     *  Bicycle prefers trails, then prefers to go straight, left, then right on streets.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        
        // Direction[] represents possible directions by preferrence (Bicycle):
        //       [myDir, myDir.left(), myDir.right()]
        return preferredDirectionTrail(theNeighbors, 
                                  new Direction[] {super.getDirection(),
                                                  super.getDirection().left(), 
                                                  super.getDirection().right()});
    }
    
    /**
     * Checks which light state the Bicycle should stop for.
     * Helper method for canPass method.
     * 
     * @param theLight the light state
     * @return true if light state is RED or YELLOW
     */
    private boolean isNotValidLight(final Light theLight) {
        
        boolean result = false;
        if (theLight.equals(Light.RED) || theLight.equals(Light.YELLOW)) {
            result = true;
        }
        
        return result;
    }
    
    /**
     * Checks if the Terrain is valid for Bicycle to pass.
     * Helper method for canPass & preferredDirection method.
     * 
     * @param theTerrain the terrain being checked
     * @return true if Terrain is not a wall or grass
     */
    private boolean isValidTerrain(final Terrain theTerrain) {
        
        boolean result = true;
        // cannot traverse walls or grass
        if (theTerrain.equals(Terrain.WALL) 
                        || theTerrain.equals(Terrain.GRASS)) {
            result = false;
        }
        
        return result;
    }
    
    /**
     * Checks if there is a trail near the Bicycle (not reverse),
     * then checks which way on the street the Bicycle wants to go (if no trail):
     * straight, left, right, or reverse.
     * Helper method for chooseDirection method.
     * 
     * @param theNeighbors map that shows what terrains are around Bicycle
     * @param theDirections possible directions of Bicycle
     * @return direction facing trail, or preferred direction on street (if no trail)
     */
    private Direction preferredDirectionTrail(final Map<Direction, Terrain> theNeighbors,
                                        final Direction[] theDirections) {
        
        //checks all directions (except reverse) for trail
        //[CHECKING REVERSE FOR TRAIL CAUSES BICYCLE TO MOVE BACK AND FORTH
        // THE TRAIL INDEFINITELY]
        for (final Direction direction : theDirections) {
            
            if (Terrain.TRAIL.equals(theNeighbors.get(direction))) {
                return direction;
            }
        }
        
        //gets valid preferred direction (straight > left > right) if no trail nearby
        return preferredDirection(theNeighbors, theDirections);
    }
    
    /**
     * Checks which direction on the street the Bicycle wants to go.
     * Goes through all directions by order (straight > left > right > reverse)
     * Helper method for chooseDirection & preferredDirectionTrail method.
     * 
     * @param theNeighbors map that shows what terrains are around Bicycle
     * @param theDirections possible directions of Bicycle (ordered by preference)
     * @return a valid preferred direction
     */
    private Direction preferredDirection(final Map<Direction, Terrain> theNeighbors,
                                        final Direction[] theDirections) {
        
        //loops through all possible directions by order
        for (Direction direction : theDirections) {
            
            //if direction is valid, return that direction
            if (isValidTerrain(theNeighbors.get(direction))) {
                return direction;
            }
        }
        
        //returns reverse if all possible directions are invalid
        return super.getDirection().reverse();
    }    
}