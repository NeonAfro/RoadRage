/**
 * TCSS 305 - Road Rage
 */

package model;

import java.util.Locale;
import java.util.Map;
import java.util.Random;


/**
 * An Abstract Parent for Vehicle Types for The Road Rage application. 
 * 
 * @author Donghwan (Luke) Chung
 * @version Winter 2023
 */
abstract class AbstractVehicle implements Vehicle {
    
    /** The type of the vehicle (subclass). */
    private String myVehicleType;
    
    /** The X coordinate of the vehicle. */
    private int myX;
    
    /** The Y coordinate of the vehicle. */
    private int myY;
    
    /** Direction the vehicle is facing. */
    private Direction myDir;
    
    /** How long the vehicle is dead for.
     *  Is 0 if the vehicle is not dead. */
    private final int myDeathTime;
    
    /** Initial Coordiate of vehicle. */
    private int[] myInitialCoordinate = new int[2];
    
    /** Initial Direction of vehicle. */
    private final Direction myInitialDirection;
    
    /** The timer for death, if the vehicle is dead. */
    private int myDeathTimer;
   
    /**
     * 
     * @param theX sets myX coordinate
     * @param theY sets myY coordinate
     * @param theDir sets direction for myDir
     * @param theDeathTime sets myDeathTime
     */
    protected AbstractVehicle(final int theX, final int theY, 
                              final Direction theDir, 
                              final int theDeathTime) {
        myX = theX;
        myY = theY;
        myDir = theDir;
        myInitialCoordinate[0] = theX;
        myInitialCoordinate[1] = theY;
        myInitialDirection = theDir;
        myDeathTimer = 0;
        myDeathTime = theDeathTime;
        
        // hold vehicle type (subclass) in this class
        setVehicleType();
    }
    
    /** Checks if the vehicle can pass the given terrain, 
     *  with the given light state (RED, YELLOW, or GREEN). */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        
        boolean result = false;
        if (isValidTerrain(theTerrain)) {
            result = true;
        }
        return result;
    }

    /** Chooses the direction the vehicle wants to move.
     *  Overridden in all subclasses as they all have different ways
     *  of deciding the direction they want to move. */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        return giveRandomDirection(theNeighbors, myDir, myDir.left(), myDir.right());
    }

    /** Checks if the vehicle survives the crash,
     *  if not, becomes dead. */
    @Override
    public void collide(final Vehicle theOther) {
      
        if (theOther.isAlive() && this.isAlive() && theOther.getDeathTime() < myDeathTime) {
            myDeathTimer = myDeathTime;
        }
    }

    /** Get death time of vehicle. 
     *  This is not the timer, but the time fo*/
    @Override
    public int getDeathTime() {
        
        return myDeathTime;
    }

    /** Sends the image file of the vehicle to use for GUI. */
    @Override
    public String getImageFileName() {
       
        if (isAlive()) {
            return myVehicleType + ".gif";
        }
        
        return myVehicleType + "_dead.gif";
    }

    /** Get the direction the vehicle is facing. */
    @Override
    public Direction getDirection() {
       
        return myDir;
    }

    /** Get x coordinate of vehicle. */
    @Override
    public int getX() {
      
        return myX;
    }

    /** Get y coordinate of vehicle. */
    @Override
    public int getY() {
      
        return myY;
    }

    /** Checks if vehicle is alive. */
    @Override
    public boolean isAlive() {
       
        boolean result = true;
        if (myDeathTimer > 0) {
            result = false;
        }
        return result;
    }

    /** Checks if dead vehicle is alive yet. */
    @Override
    public void poke() {
        
        myDeathTimer -= 1;
        
        if (myDeathTimer == 0) {
            myDir = Direction.random();
        }
        
    }

    /** Reverts the vehicle's state to initial state. */
    @Override
    public void reset() {
       
        myX = myInitialCoordinate[0];
        myY = myInitialCoordinate[1];
        myDir = myInitialDirection;
        
    }

    /** Update direction the vehicle is facing. */
    @Override
    public void setDirection(final Direction theDir) {
        
        myDir = theDir;
    }

    /** Update x coordinate of vehicle. */
    @Override
    public void setX(final int theX) {
       
        myX = theX;
    }

    /** Update y coordinate of vehicle. */
    @Override
    public void setY(final int theY) {
        
        myY = theY;
        
    }
    /** Sends back vehicle type, or vehicle type_dead if it is dead. */
    @Override
    public String toString() {
        
        String result = "";
        
        if (isAlive()) {
            result = myVehicleType;
        } else {
            result = myVehicleType + "_dead";
        }
        return result;
    }
    
    /** Stores vehicle type (subclass). */
    private void setVehicleType() {
        
        final String checkType = getClass().getSimpleName().toLowerCase(Locale.US);
        
        //if vehicle type is not valid, throws exception
        if (!("atv".equals(checkType) || "bicycle".equals(checkType)
                        || "car".equals(checkType) || "human".equals(checkType)
                        || "taxi".equals(checkType) || "truck".equals(checkType))) {
            throw new IllegalArgumentException("No Vehicle SubClass: " 
                            + myVehicleType);
        }
        
        myVehicleType = checkType; 
    }
    
    /** Checks if terrain is valid.
     *  Blueprint for subclasses helper method. */
    private boolean isValidTerrain(final Terrain theTerrain) {
        
        boolean result = true;
        if (theTerrain.equals(Terrain.WALL)) {
            result = false;
        }
        return result;
    }
    
    /** Gives a random direction depending on which directions are available. 
     *  Blueprint for subclass helper method. */
    private Direction giveRandomDirection(final Map<Direction, Terrain> theNeighbors,
                                          final Direction... theDirections) {
        
        // get random direction
        final Random random = new Random();
        final int choiceDir = random.nextInt(theDirections.length);
        
        // if terrain is valid, return the random direction
        if (isValidTerrain(theNeighbors.get(theDirections[choiceDir]))) {
            return theDirections[choiceDir];
        }  
        
        /** If possible directions are exhausted, turns vehicle around (reverse). */
        if (theDirections.length - 1 == 0) {
            return myDir.reverse();
            
        } else {
            
            // if terrain is invalid, create new array of directions
            // without the invalid direction and call the method again (recursion)
            final Direction[] newAvailableDirections = new 
                            Direction[theDirections.length - 1];
            int newIndex = 0;
            
            for (int i = 0; i < theDirections.length; i++) {
                if (i == choiceDir) {
                    continue;
                }
                
                newAvailableDirections[newIndex] = theDirections[i];
                newIndex++;
            }
            
            //call method again (recursion)
            return giveRandomDirection(theNeighbors, newAvailableDirections);
        }
    }
    
}