/**
 * TCSS 305 - Road Rage
 */

package model;

import java.util.Map;


/**
 * A Vehicle Type for The Road Rage application. 
 * 
 * @author Donghwan (Luke) Chung
 * @version Winter 2023
 */
public class Truck extends AbstractVehicle {

    /** Death time of Truck. Does not die.
     *  0 value used to determine if other vehicles die
     *  when colliding.
     */
    private static final int TRUCK_DEATH_TIME = 0;
    
    /**
     * Holds the direction of the crosswalk, if Truck can't move.
     * Makes the Truck go through the crosswalk when light changes.
     */
    private Direction myNextDirection;
    
    /**
     * Constructor for Truck. Keeps all variables in parent class.
     * 
     * @param theX sets theX coordinate for Truck
     * @param theY sets theY coordinate for Truck
     * @param theDir sets the direction the Truck is facing
     */
    public Truck(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, TRUCK_DEATH_TIME);
    }
    
    /** Checks if Truck can pass the given terrain with the given
     *  light sign.
     *  Truck cannot pass walls, grass, and trails.
     *  Truck only stops for RED (light) crosswalks.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
    
        //if terrain is valid, check if terrain is crosswalk with red light
        if (isValidTerrain(theTerrain)) {
            
            //cannot pass crosswalk at red light
            if (theTerrain.equals(Terrain.CROSSWALK) && isNotValidLight(theLight)) {
                
                //stops the truck at the crosswalk,
                //has to traverse crosswalk after light changes
                myNextDirection = super.getDirection();
                return false;
            }
            //if crosswalk is not red, can pass
            myNextDirection = null;
            return true;
        }
        //if terrain is not valid, cannot pass
        myNextDirection = null;
        return false;
    }
    
    /** Gives the next direction the Truck should go.
     *  Truck randomly chooses to go straight, left, or right.
     *  Truck turns back if it has no valid directions.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        
        //check if truck stopped at crosswalk
        if (myNextDirection != null) {
            return myNextDirection;
        }
        //returns a random direction (straight, left, right) [lastly: reverses]
        return giveRandomDirection(theNeighbors, super.getDirection(),
                                   super.getDirection().left(),
                                   super.getDirection().right());
    }
    
    /**
     * Checks which light state the Truck should stop for.
     * Helper method for canPass & giveRandomDirection method.
     * 
     * @param theLight the light state
     * @return true if light state is RED
     */
    private boolean isNotValidLight(final Light theLight) {
        
        boolean result = false;
        if (theLight.equals(Light.RED)) {
            result = true;
        }
        
        return result;
    }
    
    /**
     * Checks if the Terrain is valid for Truck to pass.
     * Helper method for canPass method.
     * 
     * @param theTerrain the terrain being checked
     * @return true if
     */
    private boolean isValidTerrain(final Terrain theTerrain) {
      
        boolean result = true;
        if (theTerrain.equals(Terrain.WALL) 
                        || theTerrain.equals(Terrain.GRASS) 
                        || theTerrain.equals(Terrain.TRAIL)) {
            result = false;
        }
        
        return result;
    }
    
    /**
     * Checks which random direction (straight, left, or right) Truck wants
     * to move. Reverses direction if no directions are available.
     * Helper method for chooseDirection method.
     * 
     * @param theNeighbors map that shows what terrains are around Truck
     * @param theDirections possible directions of Truck
     * @return a random direction (straight, left, or right)
     */
    private Direction giveRandomDirection(final Map<Direction, Terrain> theNeighbors,
                                          final Direction... theDirections) {
            
        //create a bag data structure
        final Bag<Direction> bag = new Bag<>();
        
        //put all direction
        for (final Direction d : theDirections) {
            bag.put(d);
        }
        
        //pull random direction from  bag
        Direction randomDir = bag.pullRandom();
        
        //while random direction is not valid,
        //keep pulling random direction from bag
        while (!isValidTerrain(theNeighbors.get(randomDir))) {
            
            //reverses if there are no more directions in bag
            if (bag.size() == 0) {
                return getDirection().reverse();
            }
            randomDir = bag.pullRandom();
        }
        //return random direction that is valid
        return randomDir;
    }
}