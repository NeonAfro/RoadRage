/**
 * TCSS 305 - Road Rage
 */

package model;

import java.util.Map;


/**
 * A Vehicle Type for The Road Rage application. 
 * 
 * @author Donghwan (Luke) Chung
 * @version Winter 2023
 */
public class Taxi extends AbstractVehicle {
    
    /** Death time of Taxi. */
    private static final int TAXI_DEATH_TIME = 15;
    
    /** Timer for crosswalk (if crosswalk light is RED) before Taxi can cross . */
    private int myCrossWalkStop = -1;
    
    /**
     * Constructor for Taxi. Keeps almost all variables in parent class.
     * 
     * @param theX sets theX coordinate for Taxi
     * @param theY sets theY coordinate for Taxi
     * @param theDir sets the direction the Taxi is facing
     */
    public Taxi(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, TAXI_DEATH_TIME);
    }

    /** Checks if Taxi can pass the given terrain with the given
     *  light sign.
     *  Taxi can only traverse on streets and through crosswalks.
     *  Taxi stops for RED (light) street lights.
     *  Taxi stops for RED (light) crosswalk lights temporarily.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        
        boolean result = true;
        
        if (theTerrain.equals(Terrain.CROSSWALK) 
                        && isNotValidCrossWalkLight(theLight)) {
            
            // waits 3 clock cycles on RED crosswalk lights before moving
            if (myCrossWalkStop == 0) {
                result = true;
                myCrossWalkStop = -1;
                return result;
                
            } else if (myCrossWalkStop > 0) {
                myCrossWalkStop = myCrossWalkStop - 1;
                
            } else if (myCrossWalkStop == -1) {
                myCrossWalkStop = 2;
                
            }
            
            result = false;
        }
        
        if (theTerrain.equals(Terrain.LIGHT) && isNotValidStreetLight(theLight)) {
            result = false;
        }
        
        return result;
    }

    /** Gives the next direction the Taxi should go.
     *  Taxi prefers to go straight, left, then right on streets.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        
        // Direction[] represents possible directions by preferrence (Taxi):
        //       [myDir, myDir.left(), myDir.right()]
        return preferredDirection(theNeighbors, 
                                  new Direction[] {super.getDirection(),
                                                  super.getDirection().left(), 
                                                  super.getDirection().right(),
                                                  super.getDirection().reverse()});
    }
    
    /**
     * Checks which light state, for street lights, the Taxi should stop for.
     * Helper method for canPass method.
     * 
     * @param theLight the light state
     * @return true if light state is RED
     */
    private boolean isNotValidStreetLight(final Light theLight) {
        
        if (theLight.equals(Light.RED)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Checks which light state, for crosswalk, the Taxi should stop for.
     * Helper method for canPass method.
     * 
     * @param theLight the light state
     * @return true if light state is RED
     */
    private boolean isNotValidCrossWalkLight(final Light theLight) {
        
        if (theLight.equals(Light.RED)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Checks if the Terrain is valid for Taxi to pass.
     * Helper method for canPass & preferredDirection method.
     * 
     * @param theTerrain the terrain being checked
     * @return true if Terrain is not a wall, grass, or trail
     */
    private boolean isValidTerrain(final Terrain theTerrain) {
        
        if (theTerrain.equals(Terrain.WALL) 
                        || theTerrain.equals(Terrain.GRASS) 
                        || theTerrain.equals(Terrain.TRAIL)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Checks which direction on the street the Taxi wants to go.
     * Goes through all directions by order (straight > left > right > reverse)
     * Helper method for chooseDirection method.
     * 
     * @param theNeighbors map that shows what terrains are around Taxi
     * @param theDirections possible directions of Taxi (ordered by preference)
     * @return a valid preferred direction
     */
    private Direction preferredDirection(final Map<Direction, Terrain> theNeighbors,
                                        final Direction[] theDirections) {
        //create new bag
        final Bag<Direction> bag = new Bag<>();
        
        //put directions into bag
        for (final Direction d: theDirections) {
            bag.put(d);
        }
        
        //pull Direction from bag
        Direction pulledDir = bag.pull();
        
        //while the Direction pulled is not valid, keeps pulling Direction from bag
        while (!isValidTerrain(theNeighbors.get(pulledDir))) {
            pulledDir = bag.pull();
        }
        
        //return the Direction that is valid
        return pulledDir;
    }
}