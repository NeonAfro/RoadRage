/**
 * TCSS 305 - Road Rage
 */

package model;

import java.util.Map;


/**
 * A Vehicle Type for The Road Rage application. 
 * 
 * @author Donghwan (Luke) Chung
 * @version Winter 2023
 */
public class Car extends AbstractVehicle {
    
    /** Death time of Car. */
    private static final int CAR_DEATH_TIME = 15;
    
    /**
     * Constructor for Car. Keeps all variables in parent class.
     * 
     * @param theX sets theX coordinate for Car
     * @param theY sets theY coordinate for Car
     * @param theDir sets the direction the Car is facing
     */
    public Car(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, CAR_DEATH_TIME);
    }
    
    /** Checks if Car can pass the given terrain with the given
     *  light sign.
     *  Car can only traverse on streets and through crosswalks.
     *  Car stops for RED (light) street lights.
     *  Car stops for YELLOW & RED (light) crosswalk lights.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
       
        //only allowed to return 3 times
        boolean result = true;
        
        if (isValidTerrain(theTerrain)) {
            
            if (theTerrain.equals(Terrain.CROSSWALK)
                            && isNotValidCrossWalkLight(theLight)) {
                result = false;
            }
            
            if (theTerrain.equals(Terrain.LIGHT) && isNotValidStreetLight(theLight)) {
                result = false;
            }
            
            return result;
        }
        
        result = false;
        return result;
    }

    /** Gives the next direction the Car should go.
     *  Car prefers to go straight, left, then right on streets.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        
        // Direction[] represents possible directions by preferrence (Car):
        //       [myDir, myDir.left(), myDir.right()]
        return preferredDirection(theNeighbors, 
                                  new Direction[] {super.getDirection(),
                                                  super.getDirection().left(), 
                                                  super.getDirection().right(),
                                                  super.getDirection().reverse()});
    }
    
    /**
     * Checks which light state, for street lights, the Car should stop for.
     * Helper method for canPass method.
     * 
     * @param theLight the light state
     * @return true if light state is RED
     */
    private boolean isNotValidStreetLight(final Light theLight) {
        
        if (theLight.equals(Light.RED)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Checks which light state, for crosswalk, the Car should stop for.
     * Helper method for canPass method.
     * 
     * @param theLight the light state
     * @return true if light state is RED or YELLOW
     */
    private boolean isNotValidCrossWalkLight(final Light theLight) {
        
        if (theLight.equals(Light.RED) || theLight.equals(Light.YELLOW)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Checks if the Terrain is valid for Car to pass.
     * Helper method for canPass & preferredDirection method.
     * 
     * @param theTerrain the terrain being checked
     * @return true if Terrain is not a wall, grass, or trail
     */
    private boolean isValidTerrain(final Terrain theTerrain) {
       
        if (theTerrain.equals(Terrain.WALL) 
                        || theTerrain.equals(Terrain.GRASS) 
                        || theTerrain.equals(Terrain.TRAIL)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Checks which direction on the street the Car wants to go.
     * Goes through all directions by order (straight > left > right > reverse)
     * Helper method of chooseDirection method.
     * 
     * @param theNeighbors map that shows what terrains are around Car
     * @param theDirections possible directions of Car (ordered by preference)
     * @return a valid preferred direction
     */
    private Direction preferredDirection(final Map<Direction, Terrain> theNeighbors,
                                         final Direction[] theDirections) {
        //create new bag
        final Bag<Direction> bag = new Bag<>();
         
        //put directions into bag
        for (Direction d: theDirections) {
            bag.put(d);
        }
         
        //pull Direction from bag
        Direction pulledDir = bag.pull();
         
        //while the Direction pulled is not valid, keeps pulling Direction from bag
        while (!isValidTerrain(theNeighbors.get(pulledDir))) {
            pulledDir = bag.pull();
        }
         
        //return the Direction that is valid
        return pulledDir;
    }
}