package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


/**
 * Bag Data Structure for The Road Rage application. 
 * 
 * Used for chooseDirection method in Vehicle classes.
 * 
 * @author Donghwan (Luke) Chung
 * @version Winter 2023
 * 
 *@param <T> Bag can be any type
 */
public class Bag<T> {
    
    /**
     * ArrayList used to hold items in the Bag.
     */
    private List<T> myBag;
    
    /**
     * Constructor for Bag Data Structure. Used to add and instantiate on same line.
     * 
     * @param theElements gets added to the bag while instantiating it.
     */
    @SafeVarargs
    public Bag(final T... theElements) {
        myBag = new ArrayList<>();
        put(theElements);
    }
    
    /**
     * Constructor for Bag Data Structure.
     */
    public Bag() {
        myBag = new ArrayList<>();
    }
    
    /**
     * Checks if the bag contains the same element.
     * 
     * @param theElement specified element being tested
     * @return true if bag has the specified element
     */
    private boolean isDuplicate(final T theElement) {
        boolean result = false;
        if (myBag.contains(theElement)) {
            result = true;
        }
        return result;
    }
    
    /**
     * Adds element(s) to bag. Duplicate elements are discarded.
     * 
     * @param theElements elements being added to bag
     */
    @SuppressWarnings("unchecked")
    public void put(final T... theElements) {
        
        int index = 0;
        for (final T o : theElements) {
            
            // check if bag has duplicates.
            // Skips this if bag size is 0, as calculating isDuplicate on
            // an empty arrayList causes error.
            if (myBag.size() > 0 && isDuplicate(o)) {
               
                try {
                    
                    // check where the duplicate exists
                    for (int i = 0; i < myBag.size(); i++) {
                        if (myBag.get(i).equals(o)) {
                            index = i;
                        }
                    }
                    throw new IllegalArgumentException("Duplicate Element");
                // Exception will print on console the elements that were not added
                // the bag will still keep adding elements without stopping program
                } catch (final IllegalArgumentException e) {
                    System.out.println("Element: " + myBag.get(index) 
                        + " already exists within bag, and was not added.");
                }
                    
            } else {
                // adds element to bag
                myBag.add(o); 
            }
        }
        
    }
             
    /**
     * Clears the bag of all elements.
     */
    public void clear() {
        myBag.clear();
    }
    
    /**
     * Returns all the elements in the bag.
     */
    @Override
    public String toString() {
        return myBag.toString();
    }
    
    /**
     * Gets a random element from the bag. Removes element being pulled.
     * 
     * @return random element
     */
    public T pullRandom() {
        
        final Random random = new Random();
        //get random element
        final T choice = myBag.get(random.nextInt(myBag.size()));
        
        //remove the element from the bag
        remove(choice);
         //return the random element
        return choice;
    }
    /**
     * Gets the first element from the bag.
     * 
     * Used for priority selection.
     * 
     * @return 1st element in the bag
     */
    public T pull() {
        
        final T choice = myBag.get(0);
        
        remove(choice);
        
        return choice;
    }
    
    /**
     * Returns amount of elements in the bag.
     * 
     * @return amount of elements in the bag
     */
    public int size() {
        return myBag.size();
    }
    
    /**
     * Removes specified element from the bag.
     * 
     * @param theElement element being removed
     */
    private void remove(final T theElement) {
        for (int i = 0; i < myBag.size(); i++) {
            if (myBag.get(i).equals(theElement)) {
                myBag.remove(i);
            }
        }
    }
}